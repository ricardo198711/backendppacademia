/*
  Warnings:

  - Added the required column `weight` to the `exercicios` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `exercicios` ADD COLUMN `weight` DOUBLE NOT NULL;
