-- AlterTable
ALTER TABLE `exercicios` MODIFY `observacao` VARCHAR(191) NULL;
